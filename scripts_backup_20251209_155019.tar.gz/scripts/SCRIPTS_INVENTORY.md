# GraphRAG Root Scripts Inventory & Analysis

**Location**: `scripts/` (root level, not `app/scripts/`)  
**Date**: December 9, 2025  
**Purpose**: Comprehensive analysis of all root-level scripts, API overlaps, and usage recommendations

---

## Executive Summary

The `scripts/` folder contains **25+ Python scripts** and **70+ additional files** in subdirectories, organized into five categories:

1. **Data Ingestion** (3 scripts) - YouTube playlist/transcript fetching
2. **GraphRAG Experiments** (2 scripts) - Batch experiment runner and comparison
3. **Analysis & Quality** (6 scripts) - Entity types, predicates, extraction quality
4. **Development Tools** (7 scripts) - Testing, validation, cleanup
5. **Subdirectories** (3 folders) - API tests, repositories, testing utilities

**Key Findings**:
- ✅ **No problematic API duplication** - Scripts are for development/analysis
- ⚠️ **Heavy overlap with `app/scripts/`** - Some files are duplicated
- ✅ **Extensive test coverage** - 15 bash API tests + repositories query scripts
- 📌 **Not for UI use** - All scripts are backend development tools

---

## Table of Contents

1. [Directory Structure](#directory-structure)
2. [Root-Level Scripts (25)](#root-level-scripts-25)
3. [Subdirectories Analysis](#subdirectories-analysis)
4. [API Overlap Assessment](#api-overlap-assessment)
5. [Duplication with app/scripts](#duplication-with-appscripts)
6. [Recommendations](#recommendations)

---

## Directory Structure

```
scripts/
├── Root Scripts (25 Python files)
│   ├── Data Ingestion (3)
│   ├── Experiments (2)
│   ├── Analysis (6)
│   ├── Development Tools (7)
│   └── Miscellaneous (7)
├── test_api/ (15 bash test scripts)
│   └── API endpoint tests with curl
├── testing/ (4 files)
│   ├── README.md
│   └── 3 test scripts (DUPLICATES from app/scripts)
└── repositories/ (70+ files)
    ├── graphrag/ (50+ files)
    │   ├── analysis/ (6 files, DUPLICATES)
    │   ├── explain/ (7 files)
    │   ├── queries/ (13 files)
    │   └── 5 query scripts
    ├── monitoring/ (2 files)
    ├── rag/ (1 file)
    └── utilities/ (DUPLICATES)
```

---

## Root-Level Scripts (25)

### Category 1: Data Ingestion (3 scripts)

#### 1. generate_db_with_raw_videos.py

**Purpose**: Copy raw_videos from mongo_hack to 2025-12 database.

**Functionality**:
- Copies raw_videos collection between databases
- Batch processing (1000 docs/batch)
- Optional limit with `--max N`

**API Overlap**: ❌ None - Database migration utility

**Usage**:
```bash
python scripts/generate_db_with_raw_videos.py --max 100
```

**Keep?**: ✅ Yes - Database setup utility

---

#### 2. fetch_playlist_transcripts.py

**Purpose**: Fetch YouTube transcripts using YouTube Data API.

**Functionality**:
- Lists playlist videos via YouTube API
- Fetches transcripts with youtube_transcript_api
- Prefers manual captions, falls back to auto-generated
- Translation support
- Segment stitching with pause-based punctuation
- Upserts to MongoDB raw_videos

**API Overlap**: ❌ None - Data ingestion utility

**Usage**:
```bash
python scripts/fetch_playlist_transcripts.py \
  --playlist_id PLUl4u3cNGP6317WaSNfmCvGym2ucw3oGp \
  --max 10 \
  --languages en,en-US
```

**Keep?**: ✅ Yes - Essential for data ingestion

---

#### 3. transcribe_missing.py

**Purpose**: Backfill transcripts using AWS Transcribe for videos without captions.

**Functionality**:
- Downloads audio with yt-dlp
- Uploads to S3
- Creates AWS Transcribe job
- Polls for completion
- Saves transcript to MongoDB

**API Overlap**: ❌ None - AWS integration utility

**Dependencies**: AWS credentials, S3 bucket, yt-dlp

**Usage**:
```bash
python scripts/transcribe_missing.py
```

**Keep?**: ✅ Yes - Backup transcript solution

---

### Category 2: GraphRAG Experiments (2 scripts)

#### 4. run_experiments.py

**Purpose**: Batch experiment runner for GraphRAG pipelines.

**Functionality**:
- Loads experiment configs from JSON files
- Runs multiple experiments sequentially or in parallel
- Progress tracking with real-time updates
- Error handling with retry logic (up to 2 retries)
- Result collection and summary
- Saves results to `experiment_results.json`

**API Overlap**: ❌ None - Experiment orchestration (different from Stages API)

**Comparison with Stages API**:

| Feature | run_experiments.py | Stages API |
|---------|-------------------|------------|
| Config format | JSON files | HTTP POST body |
| Execution | Direct pipeline instantiation | HTTP request |
| Batch support | ✅ Multiple configs | ❌ One at a time |
| Parallel execution | ✅ ThreadPool | ❌ Sequential |
| Retry logic | ✅ Built-in | ❌ Client-side |
| Progress tracking | ✅ File-based | ✅ HTTP polling |

**Unique Value**: Batch experiments with parallel execution

**Usage**:
```bash
python scripts/run_experiments.py --configs configs/*.json --parallel
python scripts/run_experiments.py --batch-file experiments_batch.json
```

**Keep?**: ✅ Yes - Batch testing workflow

---

#### 5. compare_graphrag_experiments.py

**Purpose**: Compare multiple GraphRAG experiment results with comprehensive metrics.

**Functionality**:
- Loads stats from multiple databases
- Calculates quality metrics (modularity, density, clustering)
- Calculates coverage metrics (entities/chunk, relationships/chunk)
- Calculates performance metrics (runtime, throughput)
- Generates comparison reports (JSON, CSV, Markdown)

**Metrics Analyzed**:
- Quality: modularity, graph density, avg degree, clustering
- Coverage: chunks processed, entities/relationships per chunk
- Performance: runtime, throughput
- Community: size distribution, multi-entity percentage

**API Overlap**: ⚠️ Partial - Similar to `/api/metrics/performance` but cross-experiment

**Unique Value**:
- **Cross-experiment comparison**
- Comprehensive metric suite
- Multiple output formats

**Usage**:
```bash
python scripts/compare_graphrag_experiments.py mongo_hack exp1 exp2 --format markdown
```

**Keep?**: ✅ Yes - Experiment analysis tool

---

### Category 3: Analysis & Quality (6 scripts)

#### 6. analyze_entity_types.py

**Purpose**: Analyze entity type distribution in extraction data.

**Functionality**:
- Entity type frequency analysis
- OTHER category usage ratio calculation
- Confidence score distribution by type
- Missing/underused type identification
- Generates markdown + JSON reports

**API Overlap**: ⚠️ Partial - Type distribution available in `/api/statistics`

**Comparison**:

| Feature | Script | API |
|---------|--------|-----|
| Type counts | ✅ | ✅ |
| OTHER ratio | ✅ | ❌ |
| Confidence by type | ✅ | ❌ |
| Quality recommendations | ✅ | ❌ |
| Report generation | ✅ | ❌ |

**Unique Value**: Deep quality analysis with recommendations

**Keep?**: ✅ Yes - Quality assurance tool

---

#### 7. analyze_predicate_distribution.py

**Purpose**: Analyze predicate (relationship type) distribution and ontology coverage.

**Functionality**:
- Predicate frequency analysis
- Canonical vs non-canonical ratio
- Identifies high-frequency non-canonical predicates (gaps in ontology)
- Suggests new canonical predicates
- Suggests mappings with similarity scoring
- Generates reports with actionable recommendations

**API Overlap**: ⚠️ Partial - Predicate distribution in `/api/statistics`

**Unique Value**:
- **Ontology gap analysis**
- Mapping suggestions
- Quality recommendations

**Keep?**: ✅ Yes - Ontology development tool

---

#### 8. compare_extraction_quality.py (27KB!)

**Purpose**: Compare extraction quality across runs or configurations.

**Functionality**:
- Loads extraction data from multiple sources
- Compares entity extraction quality
- Compares relationship extraction quality
- Confidence distribution analysis
- Type distribution comparison
- Generates detailed comparison reports

**API Overlap**: ❌ None - Specialized comparison tool

**Keep?**: ✅ Yes - Quality comparison for optimization

---

#### 9. derive_ontology.py

**Purpose**: Mine extraction data to derive ontology (predicates, entity types).

**Functionality**:
- Analyzes all extraction data
- Identifies frequent predicates (>MIN_REL_FREQ)
- Groups similar predicates
- Suggests canonical predicates
- Infers type constraints (subject-predicate-object patterns)
- Generates YAML ontology files

**Output**:
- `ontology/predicates.yml`
- `ontology/entity_types.yml`

**API Overlap**: ❌ None - Ontology development

**Unique Value**: **Automated ontology generation** from data

**Keep?**: ✅ Yes - Critical for ontology evolution

---

#### 10. build_predicate_map.py

**Purpose**: Build predicate mapping dictionary for normalization.

**Functionality**:
- Analyzes predicate variations
- Builds synonym mappings
- Generates predicate_map.py for import

**API Overlap**: ❌ None - Ontology tooling

**Keep?**: ✅ Yes - Ontology maintenance

---

#### 11. validate_entity_resolution_test.py

**Purpose**: Validate entity resolution quality with test cases.

**Functionality**:
- Tests entity merging logic
- Validates canonical name generation
- Tests similarity matching
- Reports resolution quality

**API Overlap**: ❌ None - Quality validation

**Keep?**: ✅ Yes - Resolution testing

---

### Category 4: Development Tools (7 scripts)

#### 12. run_tests.py (30KB!)

**Purpose**: Comprehensive test runner for the entire project.

**Functionality**:
- Discovers all tests in tests/ directory
- Categorizes tests (unit, integration, scripts)
- Runs tests with unittest framework
- Color-coded output
- Category filtering (--category unit/integration/fast)
- Module filtering (--module core)
- Detailed reporting with timing

**API Overlap**: ❌ None - Test infrastructure

**Keep?**: ✅ Yes - Primary test runner

---

#### 13. audit_error_handling.py

**Purpose**: Quality gate - verify @handle_errors decorator usage.

**Functionality**:
- AST parsing of Python files
- Checks public functions for @handle_errors
- Reports missing decorators
- Quality gate for consistency

**API Overlap**: ❌ None - Code quality tool

**Usage**:
```bash
python scripts/audit_error_handling.py business/services
```

**Keep?**: ✅ Yes - Code quality enforcement

---

#### 14. validate_metrics.py

**Purpose**: Quality gate - verify metrics registration.

**Functionality**:
- Imports all service modules
- Validates expected metrics are registered
- Checks Prometheus export

**API Overlap**: ❌ None - Observability validation

**Keep?**: ✅ Yes - Metrics coverage verification

---

#### 15. validate_imports.py

**Purpose**: Quality gate - verify all Python files can be imported.

**Functionality**:
- Discovers all Python files in directories
- Tests imports via subprocess
- Reports import errors
- Catches syntax errors early

**API Overlap**: ❌ None - Code quality tool

**Usage**:
```bash
python scripts/validate_imports.py business app core
```

**Keep?**: ✅ Yes - Import validation

---

#### 16. pre-commit-hook.sh

**Purpose**: Git pre-commit hook for quality gates.

**Functionality**:
- Runs import validation
- Runs error handling audit
- Prevents commits with quality issues

**API Overlap**: ❌ None - Git workflow

**Keep?**: ✅ Yes - Quality enforcement

---

#### 17. quick_test.sh

**Purpose**: Fast test suite runner.

**Functionality**:
- Runs core tests only
- Quick feedback loop for development

**API Overlap**: ❌ None - Testing utility

**Keep?**: ✅ Yes - Fast testing

---

#### 18. clean_extraction_status.py

**Purpose**: Reset extraction status fields in chunks.

**API Overlap**: ❌ None - Database maintenance

**Keep?**: ✅ Yes - Cleanup utility

---

### Category 5: Archive & Setup Scripts (7 scripts)

#### 19. archive_plan.py

**Purpose**: Archive old plan files to keep workspace clean.

**API Overlap**: ❌ None - Workspace management

**Keep?**: ✅ Yes - File organization

---

#### 20. move_archive_files.py

**Purpose**: Move files to archive directories.

**API Overlap**: ❌ None - File management

**Keep?**: ✅ Yes - Organization utility

---

#### 21. clean_graphrag_fields.py

**Purpose**: Clean GraphRAG metadata fields from chunks.

**API Overlap**: ❌ None - Data cleanup

**Keep?**: ✅ Yes - Maintenance utility

---

#### 22-25. setup_validation_db.py, copy_chunks_to_validation_db.py, etc.

**Purpose**: Database setup and validation utilities.

**API Overlap**: ❌ None - Database management

**Keep?**: ✅ Yes - Setup tools

---

## Subdirectories Analysis

### test_api/ (15 bash scripts)

**Purpose**: HTTP API endpoint testing with curl.

**Files**:
- `test_entities.sh`
- `test_communities.sh`
- `test_relationships.sh`
- `test_ego_network.sh`
- `test_export.sh`
- `test_graph_statistics.sh`
- `test_quality_metrics.sh`
- `test_performance_metrics.sh`
- `test_metrics.sh`
- `test_pipeline_control.sh`
- `test_pipeline_progress.sh`
- `test_pipeline_stats.sh`
- `test_cors.sh`
- `test_edge_cases.sh`
- `test_error_handling.sh`

**API Overlap**: ❌ None - These **test** the APIs, don't duplicate them

**Status**: ⚠️ **Partially outdated** - Test old API paths (`/api/*` instead of `/graph_api/*`)

**Value**: Excellent curl-based test suite for API validation

**Recommendation**: 
- ✅ **Keep** - Update paths to new `/graph_api/` structure
- 📝 **Update** test URLs from old `/api/entities` to new `/api/entities` (endpoints same, just module moved)

---

### testing/ (4 files)

**Purpose**: Testing utilities (appears to be staging area).

**Files**:
- `README.md`
- `run_random_chunk_test.py` ⚠️ **DUPLICATE** of `app/scripts/graphrag/run_random_chunk_test.py`
- `test_community_detection.py` ⚠️ **DUPLICATE** of `app/scripts/graphrag/test_community_detection.py`
- `test_random_chunks.py` ⚠️ **DUPLICATE** of `app/scripts/graphrag/test_random_chunks.py`

**Status**: ⚠️ **3/3 files are duplicates**

**Recommendation**: 
- ❌ **Delete `testing/` folder** - Use `app/scripts/graphrag/` versions instead
- Or consolidate into one location

---

### repositories/ (70+ files!)

**Purpose**: Large collection of query, analysis, and explanation scripts.

**Structure**:

```
repositories/
├── graphrag/ (50+ files)
│   ├── analysis/ (6 files)
│   │   ├── analyze_graph_structure.py  ⚠️ DUPLICATE
│   │   ├── diagnose_communities.py     ⚠️ DUPLICATE
│   │   ├── inspect_community_detection.py  ⚠️ DUPLICATE
│   │   ├── monitor_density.py          ⚠️ DUPLICATE
│   │   ├── sample_graph_data.py        ⚠️ DUPLICATE
│   │   └── README.md
│   ├── explain/ (7 files)
│   │   ├── explain_community_formation.py
│   │   ├── explain_entity_merge.py
│   │   ├── explain_relationship_filter.py
│   │   ├── trace_entity_journey.py
│   │   ├── visualize_graph_evolution.py
│   │   └── ... (explanation utilities)
│   ├── queries/ (13 files)
│   │   ├── query_entities.py
│   │   ├── query_relations.py
│   │   ├── query_communities.py
│   │   ├── compare_before_after_*.py (4 comparison scripts)
│   │   ├── find_resolution_errors.py
│   │   ├── query_*_decisions.py
│   │   └── ... (various query utilities)
│   └── Root query scripts (5 files)
│       ├── query_entities.py
│       ├── query_relations.py
│       ├── query_graphrag_runs.py
│       ├── query_communities.py
│       └── stats_summary.py
├── monitoring/ (2 files)
│   ├── error_summary.py
│   └── metrics_summary.py
├── rag/ (1 file)
│   └── query_chunks.py
└── utilities/ (3 files)
    ├── check_data.py      ⚠️ DUPLICATE
    ├── full_cleanup.py    ⚠️ DUPLICATE
    └── seed_indexes.py    ⚠️ DUPLICATE
```

**Analysis**:

1. **analysis/** (6 files): ⚠️ **All 6 are duplicates** of `app/scripts/graphrag/`
2. **explain/** (7 files): ✅ Unique - Advanced debugging/explanation tools
3. **queries/** (13 files): ✅ Unique - Specialized query utilities
4. **Root queries** (5 files): ⚠️ Similar to API queries but more specialized
5. **utilities/** (3 files): ⚠️ **All 3 are duplicates**

**API Overlap**: ⚠️ Moderate - Query scripts overlap with API but provide CLI interface

**Recommendation**:
- ✅ **Keep explain/** - Unique debugging value
- ✅ **Keep queries/** - Specialized CLI queries
- ❌ **Delete analysis/** - Use `app/scripts/graphrag/` versions
- ❌ **Delete utilities/** - Use `app/scripts/utilities/` versions
- 🟡 **Consolidate root queries** - Merge with queries/ subfolder

---

## API Overlap Assessment

### No Overlap (18 scripts)

Scripts with **zero** API overlap (unique utilities):

| Script | Category | Purpose |
|--------|----------|---------|
| Data Ingestion (3) | Ingestion | YouTube/AWS data fetching |
| run_experiments.py | Experiments | Batch pipeline execution |
| compare_extraction_quality.py | Analysis | Quality comparison |
| derive_ontology.py | Analysis | Ontology generation |
| build_predicate_map.py | Analysis | Mapping generation |
| validate_entity_resolution_test.py | Quality | Resolution testing |
| run_tests.py | Testing | Test runner |
| audit_error_handling.py | Quality | Decorator validation |
| validate_metrics.py | Quality | Metrics validation |
| validate_imports.py | Quality | Import validation |
| pre-commit-hook.sh | Quality | Git hooks |
| quick_test.sh | Testing | Fast tests |
| Archive scripts (7) | Maintenance | File management |

**Recommendation**: ✅ Keep all - Essential development tools

---

### Partial Overlap (7 scripts)

Scripts that overlap with APIs but provide **enhanced functionality**:

#### compare_graphrag_experiments.py vs Metrics API

**Script provides ADDITIONAL**:
- ✅ Cross-experiment comparison
- ✅ Comprehensive metric suite
- ✅ Multiple output formats
- ✅ Historical trending

**Verdict**: ✅ Keep - API doesn't support cross-experiment comparison

---

#### analyze_entity_types.py vs Statistics API

**Script provides ADDITIONAL**:
- ✅ OTHER category analysis
- ✅ Confidence distribution by type
- ✅ Quality recommendations
- ✅ Report generation

**Verdict**: ✅ Keep - Deeper analysis than API

---

#### analyze_predicate_distribution.py vs Statistics API

**Script provides ADDITIONAL**:
- ✅ Canonical vs non-canonical ratio
- ✅ Ontology gap identification
- ✅ Mapping suggestions
- ✅ Quality recommendations

**Verdict**: ✅ Keep - Ontology development focus

---

#### repositories/graphrag/queries/*.py vs Graph API

**Scripts provide ADDITIONAL**:
- ✅ CLI-friendly output
- ✅ Specialized queries (before/after comparisons)
- ✅ Resolution decision queries
- ✅ Error identification

**Verdict**: ✅ Keep - Specialized debugging queries

---

## Duplication with app/scripts

### Identified Duplicates

| File | Location 1 | Location 2 | Size |
|------|------------|------------|------|
| `analyze_graph_structure.py` | `scripts/repositories/graphrag/analysis/` | `app/scripts/graphrag/` | 13KB |
| `diagnose_communities.py` | `scripts/repositories/graphrag/analysis/` | `app/scripts/graphrag/` | 8KB |
| `inspect_community_detection.py` | `scripts/repositories/graphrag/analysis/` | `app/scripts/graphrag/` | 11KB |
| `monitor_density.py` | `scripts/repositories/graphrag/analysis/` | `app/scripts/graphrag/` | 4KB |
| `sample_graph_data.py` | `scripts/repositories/graphrag/analysis/` | `app/scripts/graphrag/` | 4KB |
| `test_random_chunks.py` | `scripts/testing/` | `app/scripts/graphrag/` | 8KB |
| `run_random_chunk_test.py` | `scripts/testing/` | `app/scripts/graphrag/` | 4KB |
| `test_community_detection.py` | `scripts/testing/` | `app/scripts/graphrag/` | 4KB |
| `check_data.py` | `scripts/repositories/utilities/` | `app/scripts/utilities/` | 2KB |
| `full_cleanup.py` | `scripts/repositories/utilities/` | `app/scripts/utilities/` | 2KB |
| `seed_indexes.py` | `scripts/repositories/utilities/` | `app/scripts/utilities/seed/` | 2KB |

**Total Duplicated**: ~62KB across 11 files

**Recommendation**: 
- ❌ **Delete from `scripts/`** - Keep `app/scripts/` versions as canonical
- Or merge and keep in one location only

---

## Functionality Matrix

### What Each Layer Provides

| Functionality | Graph API | app/scripts | scripts/ (root) | Used By UI? |
|---------------|-----------|-------------|-----------------|-------------|
| **Query Graph Data** |
| Search entities | ✅ | ❌ | ❌ | ✅ GraphDash |
| Get entity details | ✅ | ❌ | ❌ | ✅ GraphDash |
| Search communities | ✅ | ❌ | ❌ | ✅ GraphDash |
| Get ego network | ✅ | ❌ | ❌ | ✅ GraphDash |
| **Statistics & Metrics** |
| Basic stats | ✅ | ❌ | ❌ | ✅ GraphDash |
| Deep analysis | ❌ | ✅ | ✅ | ❌ Backend only |
| Real-time monitoring | ❌ | ✅ | ❌ | ❌ Backend only |
| **Testing & Quality** |
| API tests | ❌ | ❌ | ✅ | ❌ Backend only |
| Test runner | ❌ | ❌ | ✅ | ❌ Backend only |
| Quality gates | ❌ | ❌ | ✅ | ❌ Backend only |
| **Data Ingestion** |
| YouTube fetch | ❌ | ❌ | ✅ | ❌ Backend only |
| AWS transcribe | ❌ | ❌ | ✅ | ❌ Backend only |
| **Experiments** |
| Batch runner | ❌ | ❌ | ✅ | ❌ Backend only |
| Comparison | ❌ | ❌ | ✅ | ❌ Backend only |
| **Analysis** |
| Entity types | ❌ | ❌ | ✅ | ❌ Backend only |
| Predicates | ❌ | ❌ | ✅ | ❌ Backend only |
| Ontology | ❌ | ❌ | ✅ | ❌ Backend only |
| **Explain & Debug** |
| Explain tools | ❌ | ❌ | ✅ | ❌ Backend only |
| Query utils | ❌ | ❌ | ✅ | ❌ Backend only |

---

## Recommendations

### Immediate Actions

#### 1. Remove Duplicates

**Delete these folders** (use `app/scripts/` versions instead):
```bash
rm -rf scripts/testing/
rm -rf scripts/repositories/graphrag/analysis/
rm -rf scripts/repositories/utilities/
```

**Rationale**: Removes ~62KB of duplicate code, reduces confusion

---

#### 2. Update test_api/ Scripts

Update bash test scripts to use correct API paths:
- Most should still work (endpoints unchanged)
- Consider consolidating with `app/graph_api/test_server.py`

---

#### 3. Consolidate Query Scripts

Move `scripts/repositories/graphrag/query_*.py` (root level) into `queries/` subfolder for better organization.

---

### For GraphDash UI Implementation

**DO**:
- ✅ Use Graph API exclusively (`http://localhost:8081/api`)
- ✅ Reference `GRAPH_API_TECHNICAL_REFERENCE.md`
- ✅ Use `app/graph_api/test_server.py` for automated testing

**DON'T**:
- ❌ Import or call functions from `scripts/`
- ❌ Use scripts for data fetching
- ❌ Expose scripts via UI

**If You Need Script Functionality**:
- Request Graph API enhancement
- Scripts can inform new endpoint design
- API team exposes functionality properly via HTTP

---

### Script Organization Proposal

**Recommended Structure**:

```
scripts/
├── ingestion/
│   ├── fetch_playlist_transcripts.py
│   ├── transcribe_missing.py
│   └── generate_db_with_raw_videos.py
├── experiments/
│   ├── run_experiments.py
│   └── compare_graphrag_experiments.py
├── analysis/
│   ├── analyze_entity_types.py
│   ├── analyze_predicate_distribution.py
│   ├── compare_extraction_quality.py
│   └── derive_ontology.py
├── quality/
│   ├── audit_error_handling.py
│   ├── validate_metrics.py
│   ├── validate_imports.py
│   └── validate_entity_resolution_test.py
├── testing/
│   ├── run_tests.py
│   ├── quick_test.sh
│   └── pre-commit-hook.sh
├── maintenance/
│   ├── clean_extraction_status.py
│   ├── clean_graphrag_fields.py
│   ├── full_cleanup.py
│   ├── archive_plan.py
│   └── move_archive_files.py
├── test_api/ (15 bash scripts)
│   └── ... (keep as-is, update paths)
└── repositories/
    ├── graphrag/
    │   ├── explain/ (7 files - keep)
    │   └── queries/ (18 files - consolidate)
    ├── monitoring/ (2 files - keep)
    └── rag/ (1 file - keep)
```

---

## Script Categories Detailed

### Data Ingestion Scripts

**Scripts**: 3 (generate_db_with_raw_videos, fetch_playlist_transcripts, transcribe_missing)

**Purpose**: Populate MongoDB with raw video data and transcripts.

**When to Use**:
- Initial data loading
- Adding new videos from YouTube playlists
- Backfilling missing transcripts

**API Overlap**: ❌ None - These are data sources, not data consumers

**Dependencies**:
- YouTube Data API key
- AWS credentials (for transcribe_missing)
- yt-dlp, boto3, google-api-python-client

---

### Experiment Scripts

**Scripts**: 2 (run_experiments, compare_graphrag_experiments)

**Purpose**: Run and compare multiple GraphRAG pipeline configurations.

**When to Use**:
- Parameter tuning
- Algorithm comparison
- Quality optimization

**API Overlap**: ⚠️ Partial - Similar to Stages API but batch-focused

**Unique Value**:
- Parallel execution
- Cross-experiment comparison
- Comprehensive metrics

---

### Analysis Scripts

**Scripts**: 6 (analyze_entity_types, analyze_predicate_distribution, compare_extraction_quality, derive_ontology, build_predicate_map, validate_entity_resolution_test)

**Purpose**: Deep analysis of extraction quality and ontology coverage.

**When to Use**:
- Quality assessment
- Ontology development
- Extraction improvement

**API Overlap**: ⚠️ Partial - Type/predicate distribution in `/api/statistics`

**Unique Value**:
- **Ontology generation** from data
- Quality recommendations
- Gap identification
- Mapping suggestions

---

### Quality Gates

**Scripts**: 4 (audit_error_handling, validate_metrics, validate_imports, validate_entity_resolution_test)

**Purpose**: Code quality enforcement and validation.

**When to Use**:
- Pre-commit hooks
- CI/CD pipelines
- Code review

**API Overlap**: ❌ None - Code quality tools

**Value**: Prevents bugs and ensures consistency

---

### Test Infrastructure

**Scripts**: 3 (run_tests.py, quick_test.sh, pre-commit-hook.sh) + 15 bash API tests

**Purpose**: Automated testing infrastructure.

**API Overlap**: ❌ None - Tests the APIs, doesn't duplicate them

**Value**: 
- Comprehensive test runner
- Fast feedback loop
- API endpoint validation

---

### Maintenance Scripts

**Scripts**: 8 (clean_*, archive_*, setup_*, copy_*)

**Purpose**: Database cleanup, file organization, environment setup.

**API Overlap**: ❌ None

**Value**: Essential for development workflow

---

## Usage Guidelines

### For Backend Developers

**Data Ingestion**:
```bash
# Fetch new videos from YouTube playlist
python scripts/fetch_playlist_transcripts.py --playlist_id PLxxx --max 50

# Backfill missing transcripts with AWS
python scripts/transcribe_missing.py
```

**Experiments**:
```bash
# Run batch experiments
python scripts/run_experiments.py --configs configs/graphrag/*.json

# Compare results
python scripts/compare_graphrag_experiments.py db1 db2 db3 --format markdown
```

**Analysis**:
```bash
# Analyze entity types
python scripts/analyze_entity_types.py --db-name 2025-12

# Analyze predicates
python scripts/analyze_predicate_distribution.py --db-name 2025-12

# Derive ontology from data
python scripts/derive_ontology.py --db 2025-12
```

**Quality Gates**:
```bash
# Validate all code
python scripts/validate_imports.py business app core
python scripts/audit_error_handling.py business
python scripts/validate_metrics.py

# Run tests
python scripts/run_tests.py -v
python scripts/quick_test.sh
```

**Maintenance**:
```bash
# Clean GraphRAG data
python scripts/clean_graphrag_fields.py

# Full reset
python app/scripts/utilities/full_cleanup.py

# Setup new database
python -c "from app.scripts.utilities.seed.seed_indexes import ensure_collections_and_indexes; ..."
```

---

### For UI Developers (GraphDash)

**DO NOT use scripts** - Use Graph API instead:

```typescript
// ✅ Correct - Use Graph API
const entities = await fetch('http://localhost:8081/api/entities/search?limit=100');

// ❌ Wrong - Don't call scripts
const entities = await execPythonScript('scripts/repositories/graphrag/query_entities.py');
```

**Reference Documents**:
1. `GraphDash/documentation/GRAPH_API_TECHNICAL_REFERENCE.md` - API docs
2. `GraphDash/documentation/BACKEND_INTEGRATION_GUIDE.md` - Integration guide
3. `GraphRAG/app/graph_api/docs/API_SPECIFICATION.md` - Full spec

---

## Maintenance Recommendations

### Short-Term (Next Session)

1. ❌ **Delete duplicate folders**:
   - `scripts/testing/` (use `app/scripts/graphrag/`)
   - `scripts/repositories/graphrag/analysis/` (use `app/scripts/graphrag/`)
   - `scripts/repositories/utilities/` (use `app/scripts/utilities/`)

2. 📝 **Update test_api/** scripts:
   - Test URLs still correct (endpoints didn't change)
   - Consider consolidating with `app/graph_api/test_server.py`

3. 📁 **Reorganize root scripts**:
   - Create subfolders: `ingestion/`, `experiments/`, `analysis/`, `quality/`, `maintenance/`
   - Move scripts into appropriate categories

### Long-Term

1. 🔄 **Consolidate repositories/graphrag/queries/**:
   - Many specialized queries could become API endpoints
   - Consider: `GET /api/debug/resolution-decisions`
   - Consider: `GET /api/debug/extraction-errors`

2. 📊 **Enhanced Statistics API**:
   - Add connected components endpoint
   - Add clustering coefficient endpoint
   - Add hub entities endpoint

3. 🧪 **Migrate bash tests**:
   - Convert `test_api/*.sh` to Python test suite
   - Integrate with `app/graph_api/test_server.py`

---

## Summary Statistics

| Metric | Count | Notes |
|--------|-------|-------|
| **Root scripts** | 25 | Python scripts at root level |
| **test_api scripts** | 15 | Bash curl tests |
| **repositories files** | 70+ | Nested query/explain/analysis scripts |
| **Total files** | 110+ | Including all subdirectories |
| **Duplicates found** | 11 | ~62KB of duplicate code |
| **API overlaps** | 7 | Partial overlap, enhanced functionality |
| **Unique scripts** | 92+ | Provide value not in APIs |

### Duplication Summary

- **11 duplicate files** across 3 folders
- **~62KB** of duplicated code
- **All duplicates** have canonical versions in `app/scripts/`
- **Recommendation**: Delete duplicates, use `app/scripts/` versions

### API Overlap Summary

- **7 scripts** with partial API overlap
- **All provide enhanced functionality** beyond API
- **None are problematic** - Scripts serve different use cases (CLI vs HTTP)
- **UI should not use any scripts** - Use Graph API exclusively

---

## Conclusion

### For GraphDash Implementation

**Primary Reference**: `GraphDash/documentation/GRAPH_API_TECHNICAL_REFERENCE.md`

**Backend API**: Graph API at `http://localhost:8081/api`

**Scripts Role**: Backend development, testing, and analysis only - **not for UI integration**

### Script Value Assessment

- ✅ **92+ unique scripts** provide essential development value
- ⚠️ **11 duplicate files** should be removed
- ✅ **All scripts should be kept** (after removing duplicates)
- ❌ **Zero scripts** are suitable for UI integration

### Next Steps

1. Remove duplicate folders (`testing/`, `repositories/graphrag/analysis/`, `repositories/utilities/`)
2. Optionally reorganize root scripts into category folders
3. Update bash test scripts if needed
4. Continue UI implementation using Graph API exclusively

---

**End of Document**

